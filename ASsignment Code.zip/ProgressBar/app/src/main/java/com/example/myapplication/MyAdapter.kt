package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(private val items: List<Item>, private val activity: MainActivity) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {


    var count : Int =  0
    var cartvalue : Int =0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item, parent, false)
        return ViewHolder(view)    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.titleTextView.text = item.name

        holder.addToCart.setOnClickListener {
            cartvalue += increaseQuantity(item, holder)
            activity.increaseProgress(cartvalue)
            Log.d("Anirudh", "The sum of the cart is : $cartvalue")
        }

        holder.removeFromCart.setOnClickListener {
            cartvalue -= decreaseQuantity(item, holder)
            activity.increaseProgress(cartvalue)
            Log.d("Anirudh", "The sum of the cart is : $cartvalue")
        }

        holder.cart.setOnClickListener {
            showPopupWindow(holder.cart, holder.cart.context, holder)
        }
    }

    private fun increaseQuantity(item: Item, holder: ViewHolder) : Int {
        var totalSumOfcart= 0
        when (item.name) {
            "item A" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count += item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()
            }
            "item B" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count += item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()            }
            "item C" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count += item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()            }
        }
        return totalSumOfcart
    }

    private fun decreaseQuantity(item: Item,  holder: ViewHolder) : Int{
        var totalSumOfcart= cartvalue
        when (item.name) {
            "item A" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count -= item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()
            }
            "item B" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count -= item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()            }
            "item C" -> {
                val string = holder.cart.text.toString()
                count = string.toInt()
                count -= item.multiple
                totalSumOfcart = item.multiple * item.eachQtyValue
                holder.cart.text = count.toString()            }
        }
        return totalSumOfcart
    }

    @SuppressLint("MissingInflatedId")
    private fun showPopupWindow(anchorView: View, context: Context, holder: ViewHolder) {
        var selectedItem : Int
        val popupView = LayoutInflater.from(context).inflate(R.layout.popup_layout, null)
        val gridView = popupView.findViewById<GridView>(R.id.gridView)
        val values = arrayOf(24, 48, 72, 96, 120, 144, 168, 192, 216, 264, 288, 312, 336, 360, 384)
        val adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, values)
        gridView.adapter = adapter
        val popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        popupWindow.isOutsideTouchable = true
        popupWindow.isFocusable = true
        gridView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
// Handle item click
            selectedItem = values[position]
            holder.cart.text = selectedItem.toString()
// Do something with the selected item
            popupWindow.dismiss()
        }
        popupWindow.showAsDropDown(anchorView)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var titleTextView : TextView
        lateinit var cart : TextView
        lateinit var addToCart : ImageView
        lateinit var removeFromCart : ImageView

        init {
            titleTextView = itemView.findViewById<TextView>(R.id.itemList)
            cart = itemView.findViewById<TextView>(R.id.cart)
            addToCart = itemView.findViewById<ImageView>(R.id.add_to_cart)
            removeFromCart = itemView.findViewById<ImageView>(R.id.remove_from_cart)
        }
    }
}