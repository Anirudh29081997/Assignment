package com.example.myapplication

data class MyData(
    val min: Int,
    val max: Int,
    val points: List<Point>,
    val items: List<Item>
)
data class Point(
    val value: Int
)
data class Item(
    val name: String,
    val multiple: Int,
    val eachQtyValue: Int
)