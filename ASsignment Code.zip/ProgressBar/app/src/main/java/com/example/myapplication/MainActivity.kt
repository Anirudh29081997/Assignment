package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson

class MainActivity : AppCompatActivity() {
    private lateinit var progressBar: ProgressBar
    private lateinit var progressDot1: View
    private lateinit var progressDot2: View
    private var progressStatus = 0
    private val totalProgressTime = 15000
    private lateinit var recyclerView: RecyclerView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        progressBar = findViewById(R.id.progress_horizontal)
        progressDot1 = findViewById(R.id.progress_dot)
        progressDot2 = findViewById(R.id.progress_dot2)
        recyclerView = findViewById(R.id.recycler_view)
        val gson = Gson()
        val jsonString = this.assets.open("items.jason").bufferedReader().use { it.readText() }
        val myData = gson.fromJson(jsonString, MyData::class.java)
//recyclerview
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = MyAdapter(myData.items, this)
    }

    fun increaseProgress(integervalue: Int) {
        progressStatus = integervalue
        if (progressStatus <= totalProgressTime) {
            progressBar.progress = progressStatus
            updateDots()
        }
    }
    private fun updateDots() {
        if (progressStatus >= 3000) {
            progressDot1.background = getDrawable(R.drawable.progress_dot_active)
        }
        if (progressStatus >= 11000) {
            progressDot2.background = getDrawable(R.drawable.progress_dot_active)
        }
    }
}